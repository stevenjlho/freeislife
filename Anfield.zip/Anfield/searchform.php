<form method="get" id="searchform" role="form" class="searchform form-inline navbar-form navbar-right" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<div class="form-group">
		<input type="text" class="form-control" name="s" id="s" placeholder="Search" />
	</div>
	<button type="submit" id="searchsubmit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
</form>
