<ul class="pager">
       <li class="previous"><?php previous_posts_link('&larr; 上一页'); ?></li>
       <li class="next"><?php next_posts_link('下一页 &rarr;'); ?></li>
</ul>
