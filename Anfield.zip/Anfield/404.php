<?php get_header(); ?>
	<div id="main">
		<div class="erroepage">
			<iframe scrolling='no' frameborder='0' src='http://yibo.iyiyun.com/js/yibo404/key/4345' width='640' height='462' style='display:block;'></iframe>
		</div>
	</div>

<?php get_footer(); ?>