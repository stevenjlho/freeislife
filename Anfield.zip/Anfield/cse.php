<?php
/*
Template Name: cse
*/
?>
<?php get_header(); ?>
<div id="warp">
<div id="main" class="fl">

<div id="cse-search-results"></div>

<div id="cse-search-results"></div>
<script type="text/javascript">
  var googleSearchIframeName = "cse-search-results";
  var googleSearchFormName = "cse-search-box";
  var googleSearchFrameWidth = 650;
  var googleSearchDomain = "www.google.com";
  var googleSearchPath = "/cse";
</script>
<script type="text/javascript" src="http://www.google.com/afsonline/show_afs_search.js"></script>


</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
